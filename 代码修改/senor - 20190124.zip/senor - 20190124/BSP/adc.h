#ifndef __ADC_H
#define __ADC_H
#ifdef __cplusplus
extern "C" {
#endif

#include "stm32l1xx.h"

void ADC_Config(void);

void Get_ADC(uint8_t channel);

#ifdef __cplusplus
}
#endif
#endif

/*******************************************************************************/






