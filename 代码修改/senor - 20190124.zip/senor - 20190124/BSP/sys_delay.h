#ifndef SYS_DELAY_H
#define SYS_DELAY_H
#include "stm32l1xx.h"
void delay_ms(uint16_t nms);
void delay_us(uint16_t nus);
#endif

