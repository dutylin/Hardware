
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'RF_0913_F042F6P6_ID' 
 * Target:  'RF_0913_F042F6P6' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f0xx.h"


#endif /* RTE_COMPONENTS_H */
